
Tievie — v3.30 rollback bundle
--------------------------------
This zip contains the last known-good files you uploaded in this chat:
- index.html
- sw.js
- manifest.json
- any tievie-fixes-*.js found

How to deploy on GitHub Pages:
1) Drag *all* files from this zip into the root of your repo (replace existing).
2) Wait for the green "github-pages" deployment.
3) Hard-refresh in Safari: Develop → Empty Caches, then ⌥⌘R.
4) Visit: https://udouble.github.io/tievie/index.html?bust=v330

Notes:
- No code changes were made; this is a pure rollback of the last files you provided.
- If icons/ or data/ folders exist in your repo, keep them as-is.
